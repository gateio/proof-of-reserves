package global

import "gate-zkmerkle-proof/config"

var Cfg *config.Config

//witnessConfig := &config.Config{}
